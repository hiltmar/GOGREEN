<?php
	require "config.php"; // pdo connection details

	// start / continue session to get session vars
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	

	// get posted values
	$commentid = $_POST['passedcommentid'];
	$id = $_POST['passedticketid'];
	$comment = $_POST['passedcomment'];
	
	// quick data sanity check
	if ($comment == '' || $id == '')
	{
		die ('Warning : please enter a comment.');
	}
	
	// begin a transaction 
	$dbo->beginTransaction();
	
	$sqlerror = '';
	$sqlerrorcode = '';

	if ($_SESSION['authuser'] != '')
	{
	    $updatedby = $_SESSION['authuser'];
	}
	else 
	{
	    $updatedby = 'Visitor';
	}
	
	$querystring = "insert comments values (default, ?, ?, now(), ?)";
	
	try
	{
		$stmt = $dbo->prepare ($querystring);
		$stmt->execute(array(
				$id,
	        	$comment,
		        $updatedby));
	}
	catch(PDOException $exception)
	{
		$sqlerror = $exception->getMessage();
		$sqlerrorcode = $exception->getCode();
	}
	
	if ($sqlerror != '')
	{
		// rollback and error
		$dbo->rollback();
			
		// more verbose 
		die ("Error : " .  $sqlerrorcode . " message " . $sqlerror);
		die ("Error : " .  $sqlerrorcode);
	}

	$returnmessage = "Successfully Added Comment";
	
	// finally commit
	$dbo->commit();

	echo($returnmessage);

    
?>