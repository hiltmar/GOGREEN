<?php

    require "config.php"; // pdo connection details

	$passedkey = $_POST['passedkey'];
	$passedticketid = $_POST['passedticketid'];
	
	if ($passedticketid != '')
	{
	    $querystring = "select * from tickets where ticket_id = ?";
	    $stmt = $dbo->prepare ( $querystring );
	    $stmt->execute (array ($passedticketid));
	}
	else
	{
	    $querystring = "select * from tickets where id = ?";
	    $stmt = $dbo->prepare ( $querystring );
	    $stmt->execute (array ($passedkey));
	}
	
    	
    $num_rows_returned = $stmt->rowCount();
    $rows = $stmt->fetchAll ( PDO::FETCH_ASSOC );
    
    if ($num_rows_returned > 0) 
    {
    	// only 1 row should be returned but handle it this way anyway
    	foreach ( $rows as $value )
    	{
    		
    		$r = '<script>';
    		
    		$r = $r . '$("#ticketstatus").html("' . 'Status : ' . $value['status'] . '");';
    		
    		// now openclose button text
    		if ($value['status'] == 'Open')
    		{
    		    $r = $r . '$("#ticketopenclosebutton").html("Close");';
    		}
    		else
    		{
    		    $r = $r . '$("#ticketopenclosebutton").html("Re-open");';
    		}
    		
    		
    		$r = $r . '$("#ticketformtitle").html("' . 'View Support Ticket' . '");';
    		$r = $r . '$("#hidden_id").val("' . $value['id'] . '");';
    		$r = $r . '$("#ticket_type").val("' . $value['type'] . '");';
    		$r = $r . '$("#ticket_name").val("' . $value['name'] . '");';
    		$r = $r . '$("#ticket_job_title").val("' . $value['job_title'] . '");';
    		$r = $r . '$("#ticket_email_address").val("' . $value['email_address'] . '");';
    		$r = $r . '$("#ticket_telno_1").val("' . $value['telno_1'] . '");';
    		$r = $r . '$("#ticket_contact_method").val("' . $value['contact_method'] . '");';
    		$r = $r . '$("#ticket_details").val("' . str_replace("\n", '\n', $value['details']) . '");';
    		
    		// swap \n for \n that actually works in textarea --- witchcraft
    		// $r = $r . '$("#ticket_details").val("' . str_replace("\n", '\n', $value['details']) . '");';

    		$r = $r . '</script>';
    		
    		echo $r;
    		
    	}
    }
    else 
    {
        echo "ERROR : Record not found - it may have been deleted by another user." . $passedkey . 'XXX';
    	
    }
    
?>
