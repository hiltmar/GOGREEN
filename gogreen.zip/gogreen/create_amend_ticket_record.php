<?php
	//include ('email.php');
	require "config.php"; // pdo connection details
	//include('mailcontent.php');

	// start / continue session to get session vars
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}

	$id = urldecode($_POST['hidden_id']); // from hidden field cos field is a label
	$type = urldecode($_POST['ticket_type']);
	$name = urldecode($_POST['ticket_name']);
	$jobtitle = urldecode($_POST['ticket_job_title']);
	$emailaddress = urldecode($_POST['ticket_email_address']);
	$telno1 = urldecode($_POST['ticket_telno_1']);
	$contactmethod = urldecode($_POST['ticket_contact_method']);
	$details = urldecode($_POST['ticket_details']);

	
	// remove thousand separators from numbers e.g.
	// $deal_volume_agreed = str_replace (',','', $deal_volume_agreed);
	
	// belts and braces for dates e.g.
	// if (preg_match("#^[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}$#", $start_date) === 0) {$start_date = '01-01-2000';}
	// $date = DateTime::createFromFormat('d-m-Y', $start_date);
	// $start_date = $date->format('Y-m-d H:i:s');

	// catch blank name field
	// catch duplicate key constraint and handle nicely
	if ($name == '')
	{
	    die ("Error : " . " You Must Enter A Name.");
	}
	
	// begin a transaction
	$dbo->beginTransaction();
	
	$sqlerror = '';
	$sqlerrorcode = '';
	$lastid = '';
	
	if ($id == '')
	{
				    
		$querystring = 'insert tickets values(default, UUID(), ?, ?, ?, ?, ?, ?, ?, ?, now(), ?)';
		
		try
		{
			$stmt = $dbo->prepare ($querystring);
				
			$stmt->execute(array(
				        $type,
						$name,
			            $jobtitle,
			            $emailaddress,
			            $telno1,
			            $contactmethod,
			            $details,
			            'Open',
						$_SESSION['authuser']));

			// now get identity value
			$lastid = $dbo->lastInsertId();
				
		}
		catch(PDOException $exception)
		{
			$sqlerror = $exception->getMessage();
			$sqlerrorcode = $exception->getCode();
		}
		
		if ($sqlerror != '')
		{
			// rollback and error
			$dbo->rollback();
			
			// catch duplicate key constraint and handle nicely
			if (strpos($sqlerror, 'Integrity constraint violation') != 0)
			{
			    die ("Error : " . " This ticket already exists in Support Ticket System.");
			}
			    
			// more verbose 
			die ("Error : " .  $sqlerrorcode . " message " . $sqlerror);
			die ("Error : " .  $sqlerrorcode);
		}
			
				
		// finally commit
		$dbo->commit();

		echo("Successfully Created Ticket Record<br><br><span style='font-size: 15px;'>An email link to this ticket will be sent to you</span>" . "|||" . $lastid);
		
	}
	else 
	{

		// update existing record
		$querystring = 'update tickets set
                        type = ?, 
                        name = ?,
                        job_title = ?,
                        email_address = ?,
                        telno_1 = ?,
                        contact_method = ?,
                        details = ?,
		                updated_datetime = now(), login_name = ? where id = ?';
		try
		{
			$stmt = $dbo->prepare ($querystring);
			$stmt->execute(array(
			               $type,
			               $name,
			               $jobtitle,
			               $emailaddress,
			               $telno1,
			               $contactmethod,
			               $details,
			               $_SESSION['authuser'],
					       $id));
		}
		catch(PDOException $exception)
		{
			$sqlerror = $exception->getMessage();
			$sqlerrorcode = $exception->getCode();
		}
		
		if ($sqlerror != '')
		{
			// rollback and error
			$dbo->rollback();
				
			// more verbose
			die ("Error : " .  $sqlerrorcode . " message " . $sqlerror);
			die ("Error : " .  $sqlerrorcode);
		}

		// finally commit
		$dbo->commit();
		
        echo("Successfully Updated Ticket Record" . "|||" . $id);
		
	}
	
    
?>