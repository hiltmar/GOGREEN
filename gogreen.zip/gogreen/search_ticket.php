<?php

    // $id = urldecode($_POST['hidden_id']); // from hidden field cos field is a label
    $type = urldecode($_POST['ticket_type']);
    $name = urldecode($_POST['ticket_name']);
    $jobtitle = urldecode($_POST['ticket_job_title']);
    $emailaddress = urldecode($_POST['ticket_email_address']);
    $telno1 = urldecode($_POST['ticket_telno_1']);
    $contactmethod = urldecode($_POST['ticket_contact_method']);
    $details = urldecode($_POST['ticket_details']);
    
	require "config.php"; // pdo connection details
    
    // build querystring
    $querystring = "";
    $wherestring = "";
    
    $wherestring = "type like ?" .
    				" and name like ?" .
    				" and job_title like ?" .
    				" and email_address like ?" .
    				" and telno_1 like ?" .
    				" and contact_method like ?" .
                    " and details like ?";
	
    $querystring = "select * from tickets";
    if ($wherestring != "") {$querystring = $querystring . " where " . $wherestring;}
    
    //file_put_contents(".\logfile.txt", $querystring . " Query called WITH - " . "\r\n", FILE_APPEND);
    
    $stmt = $dbo->prepare ( $querystring );
   	$stmt->execute (array ($type . '%',
    					   $name . '%',
   	                       $jobtitle . '%',
   	                       $emailaddress . '%',
   	                       $telno1 . '%',
   	                       $contactmethod . '%',
   	                       $details . '%'));
    	
    $num_rows_returned = $stmt->rowCount();
    $rows = $stmt->fetchAll ( PDO::FETCH_ASSOC );
    
    $r = '';

    $namestyle = 'style="min-width:100px;"';
    $typestyle = 'style="min-width:120px;"';
    $jobtitlestyle = 'style="min-width:150px;"';
    $emailaddressstyle = 'style="min-width:200px;"';
    $telnostyle = 'style="min-width:110px;"';
    $contactmethodstyle = 'style="min-width:120px;"';
    $detailsstyle = 'style="min-width:120px;"';

    
    if ($num_rows_returned > 0) 
    {

    	$r = '<div class="selectBox">
    	<table id="ticketsearchresultstable" class="cmssearchtable">
    	<thead>
    	<tr>
		<th ' . $namestyle . ' class="searchtableheader">Name</th>    			
		<th ' . $typestyle . ' class="searchtableheader">Type</th>
		<th ' . $jobtitlestyle . ' class="searchtableheader">Job Title</th>
		<th ' . $emailaddressstyle . ' class="searchtableheader">Email Address</th>
		<th ' . $telnostyle . ' class="searchtableheader">Contact No.</th>
    	<th ' . $contactmethodstyle . ' class="searchtableheader">Contact Method</th>
        <th ' . $detailsstyle . ' class="searchtableheader lastsearchtablefield">Details</th>
    	</tr>
    	</thead>
    	<tbody>';
   
    	
     	foreach ( $rows as $value )
     	{
     		$r = $r . '<tr onclick="selectRow(this);">
    					<td data_id_number="' . $value['id'] . '" class="name">' . $value['name'] . '</td>     				
                        <td>' . $value['type'] . '</td>
                        <td>' . $value['job_title'] . '</td>
                        <td>' . $value['email_address'] . '</td>
                        <td>' . $value['telno_1'] . '</td>
                        <td>' . $value['contact_method'] . '</td>
                        <td>' . $value['details'] . '</td>
    					</tr>';
     		
     	}
    	
    	$r = $r . '</tbody>
    				</table>
    				</body>
    				</div>';
    			
    	// put a hidden input on the end to hold the value of the last selected result
    	$r = $r . '<input type="hidden" id="returnedkey" name="returnedkey" value="">';
    	
    	$r = $r . '<script>$("#ticketsearchmatchedrecords").html("' . $num_rows_returned . ' Record(s) Matched' . '");</script>';
    	
    	echo $r;
    	
    }
    else 
    {
    	$r = $r . '<div style="position: absolute; top:45%; left:55%;  transform: translate(-50%, -47%); width:600px; height: 50px; color: #B2AFAC; font-size: 60px;">No Matches Found</div>';
    	$r = $r . '<script>$("#ticketsearchmatchedrecords").html("' . $num_rows_returned . ' Record(s) Matched' . '");</script>';
    	echo $r;
    	
    }
    
?>

<style type="text/css">
.selectBox {
	border-color:#2A343E;
	width: 100%;
	height: 100%;
	margin: 0px auto;
	overflow: auto;
	cursor: pointer;
}

.selectBox table {
	border-collapse: collapse;
	margin: 1px;
}


.selectBox th {
	border-right: 1px solid;
	background-color: #2A343E;
	color:#ffffff;
	padding: 2px;
	height: 20px;
	text-align: left;
	font-weight: normal;
}

.selectBox td {
	padding: 2px;
	height: 15px;
	border: 1px dotted;
	border-left: none;
	border-right: 1px dotted;
}

.selectBox td.last {
	border-right: 1px solid;
}

.selectBox td.first {
	*border-left: 1px solid;
}


</style>
<script type="text/javascript">

function selectRow(r)
{
	// turn on the ok button
	$("#ticketsearchresultsokbutton").attr("disabled", false);
	
	// to give the impression of single selects only first make sure the rest of table is painted in unselected colours
	$("#ticketsearchresultstable tr").css("background","white");
	$("#ticketsearchresultstable tr").css("color","black");

	// now set the selected row colours
	r.style.backgroundColor = '#3399FF';
	r.style.color = 'white';
}
</script>

<script>

$(".selectBox table tr").click(function(){

	// put returned key in hidden input
	$("#returnedkey").val($(this).find('td:first').attr('data_id_number'));
	
});

</script>