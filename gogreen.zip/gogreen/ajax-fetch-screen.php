<?php
require "config.php"; // pdo connection details

//vars
$sqlerror = '';
$sqlerrorcode = 0;


if (isset($_POST['screenname']))
{
    $screenname = $_POST['screenname'];
}
else
{
    $screenname = '';
}


if ($screenname == '1')
{
    include('ticketform.php');
}
else
{
    // catch all unknown options - i.e. under construction
    echo '<div class="underconstructiondiv"><div class="underconstructionmessagediv">' . $screenname . ' Under Construction' . '</div></div>';
    
}

?>

