<?php
	//include ('email.php');
	require "config.php"; // pdo connection details
	//include('mailcontent.php');

	// start / continue session to get session vars
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}

	$passedid = $_POST['passedid'];
	$passedstatus = $_POST['passedstatus'];
	
	// begin a transaction
	$dbo->beginTransaction();
	
	$sqlerror = '';
	$sqlerrorcode = '';

	if ($passedstatus == 'Status : Open')
	{
	   $querystring = 'update tickets set status = "Closed" where id = ?';
	}
	else
	{
	    $querystring = 'update tickets set status = "Open" where id = ?';
	}
	
	try
	{
		$stmt = $dbo->prepare ($querystring);
		$stmt->execute(array($passedid));
	}
	catch(PDOException $exception)
	{
		$sqlerror = $exception->getMessage();
		$sqlerrorcode = $exception->getCode();
	}
	
	if ($sqlerror != '')
	{
		// rollback and error
		$dbo->rollback();
			
		// more verbose
		die ("Error : " .  $sqlerrorcode . " message " . $sqlerror);
		die ("Error : " .  $sqlerrorcode);
	}

	// finally commit
	$dbo->commit();


	if ($passedstatus == 'Status : Open')
	{
	    echo("Successfully Closed Ticket");
	}
	else
	{
	    echo("Successfully Re-opened Ticket");
	}
	
    
?>