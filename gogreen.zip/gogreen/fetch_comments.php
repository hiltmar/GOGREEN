<?php

    require "config.php"; // pdo connection details
    
    $ticketid = urldecode($_POST['passedticketid']);

	$rfccommentstable = '';
	$rfccommentsheader = '';
	$rfccommentsdata = '';
	$rfccommentcount = 0;
	
	$querystring = "select c.*, DATE_FORMAT(lastupdated, '%d-%m-%Y  %H:%i') as added from comments c where ticket_id = ?";
	
	$stmt = $dbo->prepare ( $querystring );
	$stmt->execute ( array ($ticketid) );
	$num_rows_returned = $stmt->rowCount ();
	$rows = $stmt->fetchAll ( PDO::FETCH_ASSOC );
	
	if ($num_rows_returned > 0)
	{
	    
	    // vars to set grid properties
	    $lineheight = 12;
	    $padding = 6;
	    $numcolumns = 15; // used to set up for headers i.e. colspan
	    
	    // set up tables
	    $rfccommentstable = $rfccommentstable . '<table cellpadding="0" cellspacing="0" border="0"' . ' class="table table-striped table-bordered mycommentsgrids" id="rfccommentstable" style = "width: 100%; border-top-width: 0px; padding:0px; display:block; font-size: 12px; max-height:170px; overflow-y: scroll;">' . '<tbody>';
	    
	    $rfccommentsheader = $rfccommentsheader . '<thead>
					<tr>
					<th style="background-color: #73B873; color: #ffffff; width:100px;line-height:' . $lineheight . 'px; padding:' . $padding . 'px">Added By</th>
					<th style="background-color: #73B873; color: #ffffff; width:155px;line-height:' . $lineheight . 'px; padding:' . $padding . 'px">Added</th>
					<th style="background-color: #73B873; color: #ffffff; width:800px; line-height:' . $lineheight . 'px; padding:' . $padding . 'px">Details</th>
					</tr>
					</thead>';
	    
	    $rfccommentssdata = '<tr>';
	    
	    foreach ( $rows as $value )
	    {
	        $rfccommentsdata = $rfccommentsdata . '<tr>' .
	   	        '<td id="' . $value ['comment_id'] . '" style="line-height:' . $lineheight . 'px; padding:' . $padding . 'px">' . $value ['updatedby'] . '</td>' .
	   	        '<td style="line-height:' . $lineheight . 'px; padding:' . $padding . 'px">' . $value ['added'] . '</td>' .
	   	        '<td style="line-height:' . $lineheight . 'px; padding:' . $padding . 'px">' . $value ['details'] . '</td>' . '</tr>';
	        
	        $rfccommentcount++;
	    }
	    
	    // now paste it all together
	    $rfccommentstable = $rfccommentstable . $rfccommentsheader . $rfccommentsdata . '</tbody></table>';
	}
	else
	{
	    $rfccommentstable = '<label class="nocommentlabel">There are currently no comments for this ticket.</label>';
	}
	
	echo $rfccommentstable;
	
?>