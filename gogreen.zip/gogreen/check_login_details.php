<?php
	require "config.php"; // pdo connection details
	require "const.php"; // app constants
	require "pbkdf2.php"; // salt and hash
	
	// start / continue session to get session vars
	if (session_status() == PHP_SESSION_NONE) {
	    session_start();
	}
	
	// quick double check here
	if ($_POST['passedpwd'] == '')
	{
		echo $GLOBALS['login_failed'];
	}
	else
	{
	
		$sqlerror = '';
		$sqlerrorcode = '';
		
		// salt and hash plus iteration
		// get salt and iterations
		
		$querystring = "select * from users where name = ?";
		//$querystring = "select u.*, a.email_address as id from users u left outer join addresses a on u.email_address = a.email_address where u.email_address = ?";
		
		try 
		{
    		$stmt = $dbo->prepare ($querystring);
			$stmt->execute (array ('admin'));
			$num_rows_returned = $stmt->rowCount();
			$rows = $stmt->fetchAll ( PDO::FETCH_ASSOC );
		} 
		catch(PDOException $exception)
		{ 
			$sqlerror = $exception->getMessage();
			$sqlerrorcode = $exception->getCode();
		}
	
		if ($sqlerror != '')
		{
			// more verbose 
			// echo "An unexpected error has occurred : " .  $sqlerrorcode . " message " . $sqlerror;
			echo "An unexpected error has occurred : " .  $sqlerrorcode;
		}
		else
		{
			// no error
			// is there a row returned
			if ($num_rows_returned > 0)
			{
				// ok check password hash and salt with iterations
				$salt = $rows[0]['salt'];
				$iterations = $rows[0]['iterations'];
			
				$passhash = pbkdf2('SHA512', $_POST['passedpwd'], $salt, $iterations, 256);
				
				// check hashes
				if ($rows[0]['password'] == $passhash)
				{
					// logged in successfully
					// set the session var

					$_SESSION['authuser'] = $rows[0]['name'];
					
					echo $GLOBALS['login_success'];
					
				}
				else 
				{
					// login failed 
					// blank the session vars
					$_SESSION['authuser']='';
					
					echo $GLOBALS['login_failed'];
				}
			
			}
			else
			{
				// no match found for user name
			    echo $GLOBALS['name_not_recognised'];
			}
			
		}
		
	}
	
?>