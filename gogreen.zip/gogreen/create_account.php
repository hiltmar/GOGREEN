<?php
	//include ('email.php');
	require "config.php"; // pdo connection details
	require "pbkdf2.php"; // salt and hash
	
	//include('mailcontent.php');
	// start / continue session to get session vars
	session_start();
	
// 	CREATE TABLE `users` (
// 			`email_address` varchar(200) NOT NULL,
// 			`name` varchar(200) NOT NULL,
// 			`password` varchar(30) NOT NULL,
// 			`creation_date` datetime default '2000-01-01 00:00:00',
// 			PRIMARY KEY  (`email_address`)
// 			) ENGINE=InnoDB DEFAULT CHARSET=latin1;
	
	// quick double check here
	
	// if ($_GET['passedname'] == '' or $_GET['passedemail'] == '' or $_GET['passedpwd'] == '' or $_GET['passedconfirmpwd'] == '')
	
	// CALL WITH
	// http://127.0.0.1/gogreen/create_account.php?passedname=admin&passedpwd=admin&passedconfirmpwd=admin
	
	// CHANGED TO GET FOR TEMPORARY QUICK ACCOUNT CREATION
	if ($_GET['passedname'] == '' or $_GET['passedpwd'] == '' or $_GET['passedconfirmpwd'] == '')
	{
		
		echo "ERROR : All fields must have a value.";
	}
	else
	{
	
		$sqlerror = '';
		$sqlerrorcode = '';
		
		// salt and hash plus iteration
		// generate a salt
		//$size = mcrypt_get_iv_size(MCRYPT_CAST_256, MCRYPT_MODE_CFB);
		//$salt = mcrypt_create_iv($size, MCRYPT_DEV_RANDOM);
		
		$salt = uniqid(mt_rand(), true);
		
		// iterations
		$iterations = 8192;
		
		$passhash = pbkdf2('SHA512', $_GET['passedpwd'], $salt, $iterations, 256);
		
		// end of salt and hash

		// 	begin a transaction
		$dbo->beginTransaction();
	
		$querystring = "insert into users values(?, ?, ?, ?, now())";
		
		try 
		{
    		$stmt = $dbo->prepare ($querystring);
			$stmt->execute (array (
					$_GET['passedname'],
					$iterations,
					$salt,
					$passhash));
				
		} 
		catch(PDOException $exception)
		{ 
			$sqlerror = $exception->getMessage();
			$sqlerrorcode = $exception->getCode();
		}
	
		if ($sqlerror != '')
		{
			$dbo->rollBack();
			
			// check for duplicate key i.e. email address and deal with it
			if ($sqlerrorcode == 23000) 
			{
				echo 'Name_In_Use';	
			}
			else
			{
				echo "An unexpected error has occurred : " .  $sqlerrorcode . " message " . $sqlerror;
				//echo "An unexpected error has occurred : " .  $sqlerrorcode;
				exit();
			}
		}

		// finally commit
		$dbo->commit();
			
        echo "Successfully created account";
		
	}
	
?>