<?php 
require "config.php"; // pdo connection details
require "const.php"; // app constants

// start / continue session to get session vars
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$bodymessage = '';

$headermessage = 'Raise A Support Ticket';


?>



<div class="99row-fluid99">

<div id="ticketholderborderdiv"  style="width: 950px; height: 598px; *margin-left: 25px; border: 1px solid; border-color:#ACACAC; border-radius:5px;">

<form class="form-horizontal"
      style="width: 950px; *height: 500px; *top: 170px; *position: absolute; background-color : transparent; *background-color: #ffffff; margin-left: auto; margin-right: auto;"
	  name="ticketform" id="ticketform" method="POST">

<div style="padding-top:0px; margin-bottom:0px; border-radius: 5px 5px 0px 0px; margin-right: 0px; background-color: #ffffff;" id="ticketform-header">

<label id="ticketformtitle" style="float: left; margin-left: 40px; margin-top: 15px; margin-bottom: 25px; padding-top:0px; text-align: left; color: #3D9D3D; font-size: 24px; font-weight:500;">
<?php if ($_SESSION['authuser'] != '') {echo 'Raise or Search Tickets - ' . $_SESSION['authuser'];} else {echo $headermessage;}?> </label>
<div class="statusdiv" id="ticketstatus"></div>
<div style="clear: both;></div>
</div>

<!-- hidden id -->
<input type="hidden" id="hidden_id" name="hidden_id" maxlength="50" value="<?php echo $id; ?>">

<!-- first block of controls -->
<div class="notspan6" style="width:445px; margin-left:20px;">

<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_type">Ticket Type</label>
<div class="controls">
<select style="width:265px;" id="ticket_type" name="ticket_type">
<option value="" selected></option>
<option value="General Enquiry">General Enquiry</option>
<option	value="Support Question">Support Question</option>
<option	value="Sales Question">Sales Question</option>
<option	value="Other">Other</option>
</select>
</div>
</div>


<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_name">Name</label>
<div class="controls">
<input style="width:250px;" type="text" id="ticket_name" name="ticket_name" maxlength="50" required>
</div>
</div>

<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_job_title">Job Title</label>
<div class="controls">
<input style="width:250px;" type="text" id="ticket_job_title" name="ticket_job_title" maxlength="50">
</div>
</div>


<!-- end first block of controls -->
</div>

<!-- second block of controls -->
<div class="notspan6" style="width:445px; margin-left:20px;">

<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_email_address">Email Address</label>
<div class="controls">
<input style="width:250px;" type="text" id="ticket_email_address" name="ticket_email_address" maxlength="100" required>
</div>
</div>

<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_telno_1">Contact No.</label>
<div class="controls">
<input style="width:250px;" type="text" id="ticket_telno_1" name="ticket_telno_1" maxlength="20">
</div>
</div>


<div class="control-group" style="margin-bottom: 10px;">
<label class="control-label" for="ticket_contact_method">Contact Method</label>
<div class="controls">
<select style="width:265px;" id="ticket_contact_method" name="ticket_contact_method">
<option value="" selected></option>
<option value="Email">Email</option>
<option	value="Phone">Phone</option>
</select>
</div>
</div>


<!-- end second block of controls -->
</div>

<!-- bottom block of controls -->
<div class="notspan6" style="width:910px; margin-left:20px;">

<div class="control-group" style="margin-top: 15px; margin-bottom: 10px;">
<label class="control-label" for="ticket_details">Ticket Details</label>
<div class="controls">
<textarea style="width:715px; height: 100px; vertical-align: top; display: block"
			id="ticket_details" name="ticket_details" maxlength="500"></textarea>
</div>
</div>


<label style="font-size: 20px; font-weight: 500; color: #3D9D3D">Comments</label>

<div class="table-container" id="rfccommentsdiv" style="border: 1px solid #cdcdcd; border-radius: 5px; margin-top: 10px; margin-bottom: 18px; height:170px;"><label class="nocommentlabel">There are currently no comments for this ticket.</label></div>


<!-- end bottom block of controls -->
</div>


<hr id="ticketbuttonshr" style="float:left; width:950px; *width: 1360px; height: 0px; border-bottom:1px dotted; border-color: #2A343E; border-top: 0px; padding:0px;margin:0 0 12px 0;">

<div style="clear:both;"></div>

<div class="control-group"
	 style="width: <?php if ($_SESSION['authuser'] == 'admin'){echo 415;} else {echo 250;}?>px; margin-right: auto; margin-left: auto; margin-bottom: 0px">

<div id="ticketbuttons">
<button type="submit" id="ticketsubmitbutton" name="submit" class="btn btn-success">Save</button>

<?php 

if ($_SESSION['authuser'] == 'admin')
{
    echo '<button type="button" id="ticketsearchbutton" name="search" class="btn btn-success">Search</button>
          <button type="button" id="ticketopenclosebutton" name="delete" class="btn btn-success" disabled>Close</button>';
}

?>

<button type="button" id="ticketcommentbutton" name="comment" class="btn btn-success" disabled>Add Comment</button>
<button type="reset" id="ticketresetbutton" name="reset" class="btn btn-success">Clear</button>
</div>
</div>

	
</form>
</div>
</div>

<!-- holder for ajaxed script with searched record data -->
<div id="ticketsearchresult"></div>

<!-- NEW FOR SEARCH -->

<div class="searchresultsdiv" id="searchresultsdiv">
		<div class="searchingimagediv" id="searchingimagediv">&emsp;Searching ...
			<div><img style="margin: 30px 0 0 50px;" id="refreshimage" src=".\images\search_loader.gif" height="128" width="128"></div></div>
			<div class="searchresultstableholder" id="ticketsearchresultsbox"></div>
			<div id="ticketsearchbuttondiv" style="height:30px; margin: auto;">
			<div class="control-group searchresultsbuttonholder">
   			<div class="controls">
		 	<button id="ticketsearchresultsokbutton" name="ticketsearchresultsokbutton" type="button" class="btn btn-default" disabled>OK</button>
			<button id="ticketsearchresultscancelbutton" name="ticketsearchresultscancelbutton" type="button" class="btn btn-default">Cancel</button>
			<label id=ticketsearchmatchedrecords style="float: right; color: #ffffff; margin-top: 5px;">Record(s) Matched</label>
			</div>
			</div>
		</div>
		</div>
		
<!-- END OF NEW FOR SEARCH -->

<!-- Add Comment -->

<div id = "rfcaddcommentoverlaydiv" style="position:fixed; top: 0px; left: 0px; width: 100%; height: 100%; background-color: #000000; display: none; opacity: 0.8; z-index:1000;"></div>

<div class="rfcaddcommentdiv" id="rfcaddcommentdiv">
<div id="rfcaddcommentformborderdiv"  style="*width: 910px; *height: 507px; margin-left: 0px;">

<form class="form-horizontal"
style="*width: 900px; *height: 500px; *top: 170px; *position: absolute; background-color : transparent; *background-color: #ffffff; margin-left: auto; margin-right: auto
name="rfcaddcommentform" id="rfcaddcommentform" method="POST">
<div style="padding-top:0px; margin-bottom:0px; border-radius: 5px 5px 0px 0px; margin-right: 0px; background-color: #ffffff;" id="rfcaddcommentform-header">
<label id="addeditrfccommentstitle" style="margin-left: 15px; margin-top: 20px; padding-top:0px; text-align: left; color: #3D9D3D; font-size: 24px; font-weight:500;">Add A Comment</label>
</div>

<div class="notspan6" style="width:500px;">
<input type="hidden" id="rfcaddcomment_id" name="rfcaddcomment_id" maxlength="50" value="0">
<input type="hidden" id="rfcommenttype" name="rfcommenttype" maxlength="50" value="0">
<div class="control-group" style="margin-top: 15px; margin-bottom: 10px;">
<label style = "width:50px;" class="control-label rfcaddcommentlabel" for="rfc_addcomment_comment">Details</label>
<div class="controls">
<textarea style="margin-left: -70px; width:500px; height: 80px; vertical-align: top; display: block"
id="rfc_addcomment_comment" name="rfc_addcomment_comment" maxlength="500"></textarea>
</div>
</div>
</div>
</div>

<div style="clear:both;"></div>

<div style="width:280px; margin: 0px auto 0 auto;">
<button style="margin-left:70px; margin-right:2px; margin-top:10px;" id="rfcaddcommentsavebutton" type="button" class="btn btn-success" data-dismiss="modal">Save</button>
<button style="margin-top:10px;" id="rfcaddcommentcancelbutton" type="button" class="btn btn-success" data-dismiss="modal">Cancel</button>
</div>

</form>

</div>
</div>

<!-- End of Add Comment -->



<script>

$("#ticketform").submit(function( event ) {

	// stop the submit going back to calling url 
	event.preventDefault();

	$("#ticketsubmitbutton").attr("disabled", true);
	
	var datastring = '';
		
	// now we have all the forms elements - need to write the data to disk
	// will need to call the php with all the params from here to actually write the data to disk
	
	// build data pairs
	for(var i=0; i < ticketform.elements.length; i++){
		var e = ticketform.elements[i];
	 	if (datastring != '') {datastring = datastring + '&';};
	 	datastring = datastring + e.name + '=' + encodeURIComponent(e.value);
	 	//alert(e.name+"="+e.value);
	};

	// add any extras e.g.
	// datastring = datastring + '&' + 'passedjobtype' + '=' + 'Export'; 
	
	$.ajax({
		//traditional: true,
	    type: "POST",
	    url: "create_amend_ticket_record.php",
		data: datastring,
	    success: function(myresults) 
	    {

			// alert(myresults);
			$("#messageboxmessagediv").html(myresults.split("|||")[0]);

			// populate the id field with new id
			$("#hidden_id").val(myresults.split("|||")[1]);
			
			// don't show ok button
			$("#messageboxbuttondiv").hide();
			$("#overlaymessageboxdiv").fadeIn(250);
			$("#messageboxdiv").fadeIn(500);

			if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
 			{
	 			$("#messageboxbuttondiv").show();
			}
			else
			{
		
				setTimeout(function()
				{
				// hide the messageboxdiv
				$("#messageboxdiv").hide();
				$("#overlaymessageboxdiv").fadeOut(250);
				}, 3000);

			}

			//$("#ticketsubmitbutton").attr("disabled", false);
			$("#ticketcommentbutton").attr("disabled", false);
					
			
    	} // end success fn

	}); // end ajax call

}); // end .submit


$("#ticketsearchbutton").click(function(){

	// set opacity low first
	//$("#ticketholderborderdiv").css('opacity', '0.1');

	$("#searchoverlaymessageboxdiv").fadeIn(150);
	
	// clear out previous search results
	//$('#ticketsearchresultsbox').html('');
		
	// hide previous results if any	
	$('#ticketsearchresultsbox').hide();

	// hide the buttons
	$('#ticketsearchbuttondiv').hide();
		
	// show the search screen div
	$('#searchresultsdiv').show();

	// show the searching gif div
	$('#searchingimagediv').show();


	// now the ajax call
	// for DDC below - inv_class: $("#inv_class option:selected").val()
    $.ajax({
	    type: "POST",
    	url: "search_ticket.php",
		data: {ticket_name: encodeURIComponent($('#ticket_name').val()), 
			   ticket_type: encodeURIComponent($('#ticket_type').val()),
			   ticket_job_title: encodeURIComponent($('#ticket_job_title').val()),
			   ticket_email_address: encodeURIComponent($('#ticket_email_address').val()),
			   ticket_telno_1: encodeURIComponent($('#ticket_telno_1').val()),
			   ticket_contact_method: encodeURIComponent($('#ticket_contact_method').val()),
			   ticket_details: encodeURIComponent($('#ticket_details').val())},
    	success: function(myresults) {

    		// disable the form controls - done here else DDC's don't return a value
    		$('#ticketholderborderdiv *').prop('disabled',true);

    		// hide the searching gif div
    		$('#searchingimagediv').hide();

    		// populate the results
    		$('#ticketsearchresultsbox').html(myresults);

    		// now show the results	
    		$('#ticketsearchresultsbox').show();

    		// show the buttons
    		$('#ticketsearchbuttondiv').show();
    	    		
    		
    	} // end success fn
    	
	}); // end ajax call

});



$("#ticketsearchresultsokbutton").click(function(){

	// turn off the search screen ok button
	$("#ticketsearchresultsokbutton").attr("disabled", true);
	
	// enable the form controls
	$('#ticketholderborderdiv *').prop('disabled',false);

	$("#ticketopenclosebutton").attr("disabled", false);	
	$("#ticketsubmitbutton").attr("disabled", true);
	$("#ticketcommentbutton").attr("disabled", false);
	

	$("#searchoverlaymessageboxdiv").fadeOut(150);
	
	// hide the results div
	$('#searchresultsdiv').hide();

	// pickup any selected row key value
	// alert ($("#returnedkey").val());

	if ($("#returnedkey").val() != '')
	{

		//alert($("#returnedkey").val());
		
		// now the ajax call to fetch the record and populate the fields on screen
    	$.ajax({
	    	type: "POST",
    		url: "quick_fetch_ticket.php",
			data: {passedkey: $("#returnedkey").val(), passedticketid: ''},
			//data: {assetserialno: 'hello'},
    		success: function(myresults) {

    			if ($.trim(myresults).toString().indexOf("ERROR : ") === 0)
    			{
    				// show the messageboxdiv
    				$('#messageboxheaderdiv').css("background-color","#FF0000");
    				$('#messageboxheaderdiv').css("border-color","#FF0000");
    	
    				$('#messageboxmessagediv').html(myresults);

    				// show ok button
    				$('#messageboxbuttondiv').show();
    				$('#overlaymessageboxdiv').fadeIn(250);
    				$('#messageboxdiv').fadeIn(500);
    				// end of show messageboxdiv		

    		    }
    			else
    			{
					// php passes back jquery to populate fields
    				$('#ticketsearchresult').html(myresults);

    			}
			
    		} // end success fn
    		
		}); // end ajax call

		// now get comments
    	$.ajax({
	    	type: "POST",
    		url: "fetch_comments.php",
			data: {passedticketid: $("#returnedkey").val()},
    		success: function(myresults) {

    			if ($.trim(myresults).toString().indexOf("ERROR : ") === 0)
    			{
    				// show the messageboxdiv
    				$('#messageboxheaderdiv').css("background-color","#FF0000");
    				$('#messageboxheaderdiv').css("border-color","#FF0000");
    	
    				$('#messageboxmessagediv').html(myresults);

    				// show ok button
    				$('#messageboxbuttondiv').show();
    				$('#overlaymessageboxdiv').fadeIn(250);
    				$('#messageboxdiv').fadeIn(500);
    				// end of show messageboxdiv		

    		    }
    			else
    			{
    				$('#rfccommentsdiv').html(myresults);
    			}
			
    		} // end success fn
    		
		}); // end ajax call

		
	}
	
});


$("#ticketsearchresultscancelbutton").click(function(){

	// turn off the search screen ok button
	$("#ticketsearchresultsokbutton").attr("disabled", true);
	
	// enable the form controls
	$('#ticketholderborderdiv *').prop('disabled',false);

	// always disable delete button here regardless of access	
	$("#ticketopenclosebutton").attr("disabled", true);

	$("#ticketsubmitbutton").attr("disabled", false);
	
	$("#searchoverlaymessageboxdiv").fadeOut(150);
	
	// hide the results div
	$('#searchresultsdiv').hide();
	
});


$("#ticketresetbutton").click(function(){

	$("#ticketopenclosebutton").attr("disabled", true);
	$("#ticketcommentbutton").attr("disabled", true);
	
	// reset occurs then manually clear the hidden fields
	$("#hidden_id").val('');
	$("#returnedkey").val('');

	// turn save button back on
	$("#ticketsubmitbutton").attr("disabled", false);

	$("#ticketstatus").html('');
	$('#rfccommentsdiv').html('<label class="nocommentlabel">There are currently no comments for this ticket.</label>');

});

$("#ticketopenclosebutton").click(function(){

	var $status = $("#ticketstatus").html();

	$.ajax({
		type: "POST",
		url: "openclose_ticket_record.php",
		data: {passedid: $("#returnedkey").val(), passedstatus: $status},
		success: function(myresults) {
		
			//alert(myresults);
		
			// show the messageboxdiv
			$("#messageboxheaderdiv").hide();
		
			$("#messageboxmessagediv").html(myresults);
		
			// don't show ok button
			$("#messageboxbuttondiv").hide();
			$("#overlaymessageboxdiv").fadeIn(250);
			$("#messageboxdiv").fadeIn(100);

			if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
			{
				$("#messageboxbuttondiv").show();
			}
			else
			{

				// clear screen
				//$("#ticketresetbutton").click();
				// manually clear the hidden fields
				//$("#hidden_id").val('');
				//$("#returnedkey").val('');
				
				if ($status == 'Status : Open')
				{
					$("#ticketstatus").html('Status : Closed');
					$("#ticketopenclosebutton").html("Re-open");
				}
				else
				{
					$("#ticketstatus").html('Status : Open');
					$("#ticketopenclosebutton").html("Close");
				}
				
				
				setTimeout(function()
				{
				// hide the messageboxdiv
				$("#messageboxdiv").hide();
				$("#overlaymessageboxdiv").fadeOut(250);
				}, 2000);
			
			}

		}
		
	}); // end ajax call

});

$( "#ticketcommentbutton" ).click(function() {

	$("#rfcommenttype").val('Comment');
	
	$("#addeditrfccommentstitle").html("Add A Comment");
	
	$("#rfcaddcommentoverlaydiv").fadeIn(250);	
	$("#rfcaddcommentdiv").fadeIn(500);
			
});

$("#rfcaddcommentsavebutton").click(function() {

	$.ajax({
	type: "POST",
	url: "create_amend_comment_record.php",
	data: {passedticketid: $('#hidden_id').val(), passedcomment: $('#rfc_addcomment_comment').val(), passedcommentid: $('#rfcaddcomment_id').val()},
	success: function(myresults) {

		//alert (myresults);
		
		// reset back to defaults
		$('#rfcaddcomment_id').val('0');
		$("#rfc_addcomment_comment").val('');

		// clear the form
		//$("#fetchdataholder").html('');
		$("#rfcaddcommentdiv").hide();
		$("#rfcaddcommentoverlaydiv").fadeOut(250);

		// show the messageboxdiv
			$('#messageboxheaderdiv').css("background-color","#3D9D3D");
			$('#messageboxheaderdiv').css("border-color","#3D9D3D");
			$('#messageboxtitlediv').html('Work Request System - RFCs');

		$("#messageboxmessagediv").html(myresults);
		
		// don't show ok button
		$("#messageboxbuttondiv").hide();
		$("#overlaymessageboxdiv").fadeIn(250);
		$("#messageboxdiv").fadeIn(100);


		if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
		{
			$("#messageboxbuttondiv").show();
		}
		else
		{
		
			setTimeout(function()
			{
			// hide the messageboxdiv
			$("#messageboxdiv").hide();
			$("#overlaymessageboxdiv").fadeOut(250);
			}, 2000);

		}

		// now we need to fetch the comments again 
	 	$.ajax({
	 		type: "POST",
    		url: "fetch_comments.php",
			data: {passedticketid: $("#hidden_id").val()},
 			success: function(myresults) {
 					$('#rfccommentsdiv').html(myresults);
 				} // end success fn
 			}); // end ajax call

		} // end success fn
	}); // end ajax call

});


$("#rfcaddcommentcancelbutton").click(function() {

	// reset back to defaults
	$('#rfcaddcomment_id').val('0');
	$("#rfc_addcomment_comment").val('');

	$("#rfcaddcommentdiv").hide();
	$("#rfcaddcommentoverlaydiv").fadeOut(250);
});



</script>
