<?php


$dbhost_name = "localhost";
//$dbhost_name = "127.0.0.1";
$database = "gogreen_tickets";
$username = "gogreen_ticket_user";
$password = "gg-pass-99";


try {
    $dbo = new PDO('mysql:host='.$dbhost_name.';dbname='.$database, $username, $password);
    $dbo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e)
{
    //print "Error!: " . $e->getMessage() . "<br/>";
    die("Error : " . $e->getMessage() . "<br/>");
    
}

?>

