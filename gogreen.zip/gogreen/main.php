<!DOCTYPE html>
<?php 

require "const.php"; // app constants

// start / continue session to get session vars
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$_SESSION['authuser'] = '';

if (isset($_GET['tid']))
{
    $tid = $_GET['tid'];
}
else
{
    $tid = '';
}


?>

<html lang="en">

  <head>

	<link rel="shortcut icon" href="./favicon.ico" type="image/x-icon">
	<link rel="icon" href="./favicon.ico" type="image/x-icon">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Ticket Portal</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <link href="css/gogreen.css" rel="stylesheet">

    <!-- Bootstrap JS -->
	<!-- <script src="vendor/bootstrap/js/bootstrap.js" type="text/javascript"></script> -->


  </head>

  <body>

    <!-- Navigation -->
    <div class="pageheader">
        <div class="titleclass">Support Ticket System
          	<div style="width: 580px; float: right;">
				<button style="font-size:20px; color: #73B873; width:280px;" id="menu-home" class="mybuttondiv">Home</button>
			</div>
		</div>
		<div class="underbar"></div>
	</div>

    <!-- Page Content -->

    <div id="contentholder" class="maincontentcontainer">

	<?php 
	if ($tid == '')
	{

    	echo '<div class="contentheaders">
    		Welcome to the Support Ticket portal</br>
    	</div>
		Please choose an option below</br>
		<div class="buttondivholder">
		
			<div id="visitorbuttondiv" data-panelid="1" class="screenpaneldiv" ><div style="float: left; padding-top:20px;">Visitors</div>
			<div class="control-group" style="margin-bottom: 10px;">
    		<div class="controls" style="float: left; margin-top: 60px;">
    		
			<div style="margin-left: -120px; font-size: 32px; margin-top: 40px;">Click To Enter</div>
			
			</div>
			</div>
    		<div style="float: right; margin-right: 20px; margin-top: 30px;"><img class="ts_odd_images" src="./images/home-gg.png"></div></div>
			
    		<div id="adminbuttondiv" data-panelid="2" class="screenpanel2div" ><div style="float: left; padding-top:20px;">Admin Login</div>
    		<div class="control-group" style="margin-bottom: 10px;">
    		<div class="controls" style="float: left; margin-top: 60px;">
    		<input class="registercontrols" type="password" id="signin_password" name="signin_password" maxlength="50" placeholder="Enter Admin Password" required>
			<button id="signinsigninbutton" type="button" class="btn btn-success signinregisterbutton" data-dismiss="modal" style="margin-top: -10px; *color:#2A343E; color:#fff; font-weight:500;">Sign in</button>
			</div>
			</div>
			<div style="float: right; margin-right: 20px;"><img class="ts_images" src="./images/cog-gg.png"></div></div>
			
		</div>';
	}
    ?>

	</div>
	<!-- END Page Content -->
	
    <!-- Footer -->
    <div class="container footercontainer">
       <p style="font-size: 14px; width: 1200px; margin: 30px auto 0 auto; color: #fff">Copyright &copy; MH Ticket Systems <?php echo date("Y");?></p>
    </div>

	<!-- overlays and messagebox divs -->
	<!-- page overlay for lightbox effect -->
	<div id = "overlaymessageboxdiv" style="position:fixed; top: 0px; left: 0px; width: 100%; height: 100%; background-color: #000000; display: none; opacity: 0.8; z-index:999;">
	</div>

    <!-- page overlay for lightbox effect -->
	<div id = "higheroverlaydiv" style="position:fixed; top: 0px; left: 0px; width: 100%; height: 100%; background-color: #000000; display: none; opacity: 0.8; z-index:1002;">
	</div>

    <!-- page overlay for lightbox effect for searches -->
	<div id = "searchoverlaymessageboxdiv" style="position:fixed; top: 0px; left: 0px; width: 100%; height: 100%; background-color: #000000; display: none; opacity: 0.3; z-index:999;">
	</div>


	<div id = "messageboxdiv">

	<!-- LOGO Holder if required <div style="float:left; width:0px;"><img class="logoimage" id="logoimage" style="*float:left; margin:15px 0 0 15px;" src="images/blank.png" height="0" width="0"></div> -->
	<div style="float:left; width:280px; font-size:20px; color:#3D9D3D; margin-top:34px; margin-left:17px;">Support Ticket System</div>

    <!-- loading div -->
	<div id="messageboxloadingdiv" style="display:none;"><img style="z-order:1; margin: 5px 0 0 58px;" id="refreshimage" src=".\images\ajax-loader3.gif" height="15" width="128"></div>
    <!-- end of loading div -->

	<hr style="float:left; width: 420px; height: 0px; border-bottom:1px solid #DDE2E8; border-top:0px; padding:0px;margin:10px 15px 5px 15px">

	
	<div id="messageboxmessagediv" style="*text-align:center; min-height: 70px; max-height: 75px; overflow-y: auto; float:left; color: #2A343E; font-size: 20px; width:420px; margin:30px 15px 0px 15px;"></div>

	<div style="clear: both;"></div>

	<div id="messageboxbuttondiv" style="width: 55px; margin: -10px auto 0px auto;">
	<button id="messageboxokbutton" type="button" class="btn btn-inverse" data-dismiss="modal">OK</button>
	</div>


	</div> <!-- end of messageboxdiv -->
	
    <!-- end of overlays and message divs -->	
	


    <!-- Bootstrap core JavaScript -->
	<script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>

<script>

$(function() {

	$("#messageboxokbutton").click(function() {
		$('#messageboxdiv').hide();			
		$('#overlaymessageboxdiv').fadeOut(250);
		$('#higheroverlaydiv').fadeOut(250);
	});


	$("#menu-home").click(function() {

		$('#messageboxdiv').hide();			
		$('#overlaymessageboxdiv').fadeOut(250);
		$('#higheroverlaydiv').fadeOut(250);

		location.reload();
	});
	

	$(".screenpaneldiv").click(function(event){

		if ($(this).attr("data-panelid") == "")
		{
			alert("no panel");
		}

		$.ajax({
			type: "POST",
			url: "ajax-fetch-screen.php",
			data: {screenname: $(this).attr("data-panelid")},
			success: function(myresults)
			{
				if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
				{
					alert(myresults);
				}
				else
				{
					$("#contentholder").html(myresults);
				}
			}	// end success fn
	
		}); // end ajax call
	
	}); 


	$("#signinsigninbutton").click(function(event){

		// call to check password record
		$.ajax({
			type: "POST",
			dataType: "text",
			url: "check_login_details.php",
			data: {passedpwd: $("#signin_password").val()},
			success: function(myresults) {

				//alert(myresults);
				
				// catch error - myresults only longer than 1 if an sql error occurred
	    		if ($.trim(myresults).toString().indexOf("<?php echo ($GLOBALS['login_success']); ?>") === 0)
	    		{
	        		// successfully signed in
					// call ticket screen		    		
		    		$.ajax({
		    			type: "POST",
		    			url: "ajax-fetch-screen.php",
		    			data: {screenname: "1"},
		    			success: function(myresults)
		    			{
		    				if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
		    				{
		    					alert(myresults);
		    				}
		    				else
		    				{
		    					$("#contentholder").html(myresults);
		    				}
		    			}	// end success fn
		    	
		    		}); // end ajax call

					// set home button text
		    		$("#menu-home").html("Logout Admin");
			    		
		    		
	    		}
	    		else if ($.trim(myresults).toString().indexOf("<?php echo ($GLOBALS['name_not_recognised']); ?>") === 0)
	    		{
	    			// name not recognised
	    			alert('Name Not Registered');
					// set home button text
		    		$("#menu-home").html("Home");
	    			
	    		}
	    		else if ($.trim(myresults).toString().indexOf("<?php echo ($GLOBALS['login_failed']); ?>") === 0)
	    		{
		    		alert('Incorrect Password');
					// set home button text
		    		$("#menu-home").html("Home");
		    		
	    		}
				// catch unexpected SQL error
				else if ($.trim(myresults).toString().indexOf("An unexpected error has occurred") === 0)
				{
					alert(myresults);
					// set home button text
		    		$("#menu-home").html("Home");
					
				}
					
			} // end success fn
		}); // end ajax call

	}); 


	$('#signin_password').keyup(function(event){

		if(event.keyCode == 13)
		{
			$('#signinsigninbutton').click();
		}
		
	});
		

	function fetch_ticket_from_url($passedtid)
	{

		// call ticket screen		    		
		$.ajax({
			type: "POST",
			async: false,
			url: "ajax-fetch-screen.php",
			data: {screenname: "1"},
			success: function(myresults)
			{
				if ($.trim(myresults).toString().indexOf("Warning : ") === 0 || $.trim(myresults).toString().indexOf("Error : ") === 0)
				{
					alert(myresults);
				}
				else
				{
					$("#contentholder").html(myresults);
				}

				// now the ajax call to fetch the record and populate the fields on screen
		    	$.ajax({
			    	type: "POST",
		    		url: "quick_fetch_ticket.php",
					data: {passedkey: '', passedticketid: $passedtid},
		    		success: function(myresults) {

		    			if ($.trim(myresults).toString().indexOf("ERROR : ") === 0)
		    			{
		    				// show the messageboxdiv
		    				$('#messageboxheaderdiv').css("background-color","#FF0000");
		    				$('#messageboxheaderdiv').css("border-color","#FF0000");
		    	
		    				$('#messageboxmessagediv').html(myresults);

		    				// show ok button
		    				$('#messageboxbuttondiv').show();
		    				$('#overlaymessageboxdiv').fadeIn(250);
		    				$('#messageboxdiv').fadeIn(500);
		    				// end of show messageboxdiv		

		    		    }
		    			else
		    			{
							// php passes back jquery to populate fields
		    				$('#ticketsearchresult').html(myresults);

		    			}

		    			// now we need to fetch the comments  
		    		 	$.ajax({
		    		 		type: "POST",
		    	    		url: "fetch_comments.php",
		    				data: {passedticketid: $("#hidden_id").val()},
		    	 			success: function(myresults) {
		    	 					$('#rfccommentsdiv').html(myresults);
		    	 				} // end success fn
		    	 			}); // end ajax call

		    	 		// finally enable the add comment button and diable the submit
		    		 	$("#ticketcommentbutton").attr("disabled", false);
		    		 	$("#ticketsubmitbutton").attr("disabled", true);
		    		 	
		    		 							
		    		} // end success fn
		    		
				}); // end ajax call
				
			}	// end success fn

		}); // end ajax call

	};
	
	// now if tid != '' fetch the ticket record to screen
	<?php 
	if ($tid != '')
	{
	    //echo 'alert("' . $tid . '");';
	   
	    echo 'fetch_ticket_from_url("' . $tid . '");';
	    
	}
	
	?>
	
});

</script>


</html>