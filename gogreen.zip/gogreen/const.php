<?php

$GLOBALS['login_failed'] = "failed";
$GLOBALS['login_success'] = "success";
$GLOBALS['name_not_recognised'] = "name failed";

?>

